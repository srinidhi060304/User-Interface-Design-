var a=["recalled","A werewolf boy","The Call","Confession","The Round-up","The Wailing","Unlocked","Hope","Dear Zindagi","Atrangi re","Hamid","Chichore","dilwale dulhaniya le jayenge","Raazi","Bajirao mastani","Pathaan","Sita Ramam","rrr","Majili","a aa","pushpa","Baahubali","love story","gang leader","Frozen","ready player one","flash point","Onward","godzilla","charlie and the chocolate factory","Cloudy with a chance of meat balls"];
          var b=["recalled.html","werewolf.html","call.html","confession.html","roundup.html","wailing.html","unlocked.html","hope.html","Dearzindagi.html","Atrangire.html","Hamid.html","Chichore.html","ddlj.html","Raazi.html","bajirao.html","Pathaan.html","Sita.html","rrr.html","Majili.html","Aaa.html","pushpa.html","bahubali.html","lovestory.html","gangleader.html","frozen.html","readyplayerone.html","flashpoint.html","onward.html","Godzilla.html","charlie.html","cloudy.html"];
          function see()
          {
             var x= document.getElementById("search").value.toLowerCase();
             console.log(x);
             for(let i=0;i<a.length;i++)
             {
                 if(a[i].includes(x))
                 {
                    location.href=b[i];
                 }
              }
           }


         

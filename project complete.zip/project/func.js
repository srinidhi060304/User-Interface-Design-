
function moviepage() {
  window.location.href = "anime.html";
}
function Animepage() {
  window.location.href = 'anime.html';
}
function Seriespage() {
  window.location.href = "anime.html";
}
function Kdramapage() {
  window.location.href = "anime.html";
}

var a=["assassin class","black","demon","food wars","fairy tail","jjk","kake","lie","oshi","slime"];
          var b=["assassination_classroom.html","black_clover.html","demon_slayer.html","food_wars.html","ft.html","jjk.html","kakegurui.html","lie_in_april.html","oshi_no_ko.html","slime.html"];
          function change()
          {
            location.href="anime.html";
          }
          function see()
          {
             var x= document.getElementById("Search").value.toLowerCase();
             console.log(x);
             var f=0;
             for(let i=0;i<a.length;i++)
             {
                 if(a[i]==(x))
                 {
                    f=1;
                    location.href=b[i];                    
                 }                 
             }
             if(f==0)
             {
                alert("Invalid Input!!!");
             }
          }
          function change1(x)
          {
           document.getElementById("eps").src=x;
          }
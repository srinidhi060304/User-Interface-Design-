function moviepage() {
  window.location.href = "mov.html";
}
function Animepage() {
  window.location.href = "anime.html";
}
function Seriespage() {
  window.location.href = "Page1a.html";
}
function Kdramapage() {
  window.location.href = "mainpagecopy.html";
}

